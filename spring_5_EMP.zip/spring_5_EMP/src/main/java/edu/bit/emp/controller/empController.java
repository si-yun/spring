package edu.bit.emp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.bit.emp.service.EmpService;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@AllArgsConstructor
@Log4j
public class empController {

	private EmpService service;
	
	@GetMapping("/list")
	public void list(Model model) { 
	   log.info("list");
	   model.addAttribute("list", service.getList());
	}
	@GetMapping("/emplist")
	public void list2(Model model) { 
		log.info("emplist");
		model.addAttribute("emplist", service.getList());
	}
	@GetMapping("/jquarylist")
	public void list3(Model model) { 
		log.info("jquarylist");
		model.addAttribute("jquarylist", service.getList());
	}
	@GetMapping("/tables")
	public void sbadminlist(Model model) { 
		log.info("tables");
		model.addAttribute("tables", service.getList());
	}
	@RequestMapping("/index")
	public String index() {
		log.info("index");
		return "index";
				
	}
	/*
	 * @GetMapping("/list") public void list(emplist empl) { log.info("list");
	 * 
	 * 
	 * model.addAttribute("empl", service.emplist()); }
	 */
}

