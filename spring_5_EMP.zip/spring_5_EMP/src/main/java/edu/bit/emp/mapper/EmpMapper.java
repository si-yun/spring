package edu.bit.emp.mapper;

import java.util.List;

import edu.bit.emp.vo.EmpVO;

public interface EmpMapper {

	public List<EmpVO> getList();

}
